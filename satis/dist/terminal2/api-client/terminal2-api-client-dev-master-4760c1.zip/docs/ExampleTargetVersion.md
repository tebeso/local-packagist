# ExampleTarget API Documentation

This document provides documentation for the ExampleTarget API endpoints.

## Version 1.0.0

### Changelog

- fixed issue with user login
- added support for dark mode
- updated dependencies to latest versions

### Documentation

#### Test

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

#### Getting Started

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

## Version 1.0.1

### Changelog

- this is a test

### Documentation

#### Getting Started

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

#### Authentication

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

## Version 1.0.2

### Documentation

#### Getting Started

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

#### Authentication

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

#### bla

Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

#### Configuration

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.

## Original JSON Configuration

```json
{
    "1.0.0": {
        "changelog": [
            "fixed issue with user login",
            "added support for dark mode",
            "updated dependencies to latest versions"
        ],
        "documentation": [
            {
                "topic": "Test",
                "answer": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
            },
            {
                "topic": "Getting Started",
                "answer": "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
            }
        ]
    },
    "1.0.1": {
        "changelog": [
            "this is a test"
        ],
        "documentation": [
            {
                "topic": "Test",
                "remove": true
            },
            {
                "topic": "Authentication",
                "answer": "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
            }
        ]
    },
    "1.0.2": {
        "changelog": [],
        "documentation": [
            {
                "topic": "bla",
                "answer": "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
            },
            {
                "topic": "Configuration",
                "answer": "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium."
            }
        ]
    }
}
```
