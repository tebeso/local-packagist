# API Client Package

This package provides a client for interacting with the API middleware.

## Installation

```bash
composer require terminal2/api-client
```
test
## Usage

### Authentication

There are two ways to authenticate with the API:

#### 1. Using a token directly

If you already have a valid API token, you can use it directly:

```php
use Terminal2\ApiClient\ApiClient;

$client = ApiClient::create('https://api.example.com')
    ->withToken('your-api-token');

// Now you can use the client to make API calls
$response = $client->exampleTarget()->getUsers();
```

#### 2. Using client credentials (OAuth2)

If you have client credentials (client ID and client secret), you need to:
1. Set the credentials using `withClientCredentials()`
2. Call `authenticate()` to exchange them for a token

```php
use Terminal2\ApiClient\ApiClient;

$client = ApiClient::create('https://api.example.com')
    ->withClientCredentials('your-client-id', 'your-client-secret')
    ->authenticate();

// Now you can use the client to make API calls
$response = $client->exampleTarget()->getUsers();
```

**Important:** Always call `authenticate()` after `withClientCredentials()` before making any API calls. If you don't, the client won't have a valid token and the API calls will fail.

### Making API Calls

Once authenticated, you can make API calls using the endpoint methods:

```php
// Get users with default version (latest)
$response = $client->exampleTarget()->getUsers();

// Specify a version
$response = $client->exampleTarget()->version('1.0.0')->getUsers();

// Or use a specific version directly
$response = $client->exampleTarget()->v100()->getUsers();

// Pass data to the endpoint
$response = $client->exampleTarget()->getUsers(['status' => 'active']);

// Use async mode with a callback URL
$response = $client->exampleTarget()
    ->async()
    ->withCallback('https://your-app.com/api/callback')
    ->getUsers();
```

### Handling Responses

The API client returns an `ApiResponse` object that provides methods for working with the response:

```php
$response = $client->exampleTarget()->getUsers();

// Check if the request was successful
if ($response->isSuccess()) {
    // Get the response data as an array
    $data = $response->json();

    // Process the data
    foreach ($data['users'] as $user) {
        echo $user['name'] . "\n";
    }
}

// Get the status code
$statusCode = $response->getStatusCode();

// Get the response body as a string
$body = $response->getBody();

// Get the response headers
$headers = $response->getHeaders();
```

## Available Endpoints

The following endpoints are available:
### ExampleTarget

Access the ExampleTarget endpoints using `$client->exampleTarget()`.

Available versions: 1.0.0, 1.0.1

Available endpoints:

- `getUsers()`: getUsers
- `getUsersWithTimeout()`: getUsersWithTimeout

For more details, see the [documentation](docs/ExampleTargetVersion.md).

## Error Handling

The API client throws exceptions when errors occur:

- `ApiException`: Base exception for all API-related errors
- `EndpointNotFoundException`: Thrown when an endpoint is not found

```php
use Terminal2\ApiClient\ApiClient;
use Terminal2\ApiClient\Exceptions\ApiException;
use Terminal2\ApiClient\Exceptions\EndpointNotFoundException;

try {
    $client = ApiClient::create('https://api.example.com')
        ->withClientCredentials('your-client-id', 'your-client-secret')
        ->authenticate();

    $response = $client->exampleTarget()->getUsers();
} catch (ApiException $e) {
    // Handle API-related errors
    echo "API Error: " . $e->getMessage();
} catch (\Exception $e) {
    // Handle other errors
    echo "Error: " . $e->getMessage();
}
```