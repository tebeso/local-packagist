<?php

namespace Terminal2\ApiClient\Endpoints;

use Terminal2\ApiClient\Http\HttpClient;
use Terminal2\ApiClient\Http\ApiResponse;

class ExampleTargetEndpoint
{
    private HttpClient $httpClient;
    private string $baseUrl;
    private ?string $apiToken;
    private string $version = '1.0.2'; // Default to latest version

    public function __construct(HttpClient $httpClient, string $baseUrl, ?string $apiToken)
    {
        $this->httpClient = $httpClient;
        $this->baseUrl = $baseUrl;
        $this->apiToken = $apiToken;
    }

    public function v100(): Endpoints\ExampleTarget\ExampleTargetV100
    {
        return new Endpoints\ExampleTarget\ExampleTargetV100($this->httpClient, $this->baseUrl, $this->apiToken);
    }
    public function v101(): Endpoints\ExampleTarget\ExampleTargetV101
    {
        return new Endpoints\ExampleTarget\ExampleTargetV101($this->httpClient, $this->baseUrl, $this->apiToken);
    }
    public function v102(): Endpoints\ExampleTarget\ExampleTargetV102
    {
        return new Endpoints\ExampleTarget\ExampleTargetV102($this->httpClient, $this->baseUrl, $this->apiToken);
    }

    public function version(string $version): self
    {
        $this->version = $version;
        return $this;
    }

    /**
     * Resolve the appropriate version handler based on the selected version
     */
    private function resolveVersion()
    {
        $methodName = 'v' . str_replace('.', '', $this->version);

        if (method_exists($this, $methodName)) {
            return $this->$methodName();
        }

        throw new \InvalidArgumentException("Version {$this->version} is not supported");
    }
}