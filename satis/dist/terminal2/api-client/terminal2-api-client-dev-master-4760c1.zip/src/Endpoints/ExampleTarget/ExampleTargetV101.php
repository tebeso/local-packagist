<?php

namespace Terminal2\ApiClient\Endpoints\ExampleTarget;

use Terminal2\ApiClient\Http\HttpClient;
use Terminal2\ApiClient\Http\ApiResponse;

class ExampleTargetV101
{
    private HttpClient $httpClient;
    private string $baseUrl;
    private ?string $apiToken;
    private bool $async = false;
    private ?string $callbackUrl = null;

    public function __construct(HttpClient $httpClient, string $baseUrl, ?string $apiToken)
    {
        $this->httpClient = $httpClient;
        $this->baseUrl = $baseUrl;
        $this->apiToken = $apiToken;
    }

    /**
     * Set async mode with callback URL
     */
    public function async(): self
    {
        $this->async = true;
        return $this;
    }

    /**
     * Set callback URL for async requests
     */
    public function withCallback(string $url): self
    {
        $this->callbackUrl = $url;
        return $this;
    }

    /**
     * Call the getUsers endpoint
     */
    public function getUsers(array $data = []): ApiResponse
    {
        try {
            $response = $this->httpClient->request(
                'POST',
                "{$this->baseUrl}/api",
                [
                    'headers' => [
                        'Authorization' => "Bearer {$this->apiToken}",
                        'Content-Type' => 'application/json',
                        'Accept' => 'application/json',
                    ],
                    'json' => [
                        'target' => 'ExampleTarget',
                        'version' => '1.0.1',
                        'endpoint' => 'getUsers',
                        'data' => json_encode($data),
                        'mode' => $this->async ? 'async' : 'sync',
                        'callback_url' => $this->callbackUrl,
                    ],
                ]
            );

            return $response;
        } catch (\Exception $e) {
            throw $e;
        }
    }
    /**
     * Call the getUsersWithTimeout endpoint
     */
    public function getUsersWithTimeout(array $data = []): ApiResponse
    {
        try {
            $response = $this->httpClient->request(
                'POST',
                "{$this->baseUrl}/api",
                [
                    'headers' => [
                        'Authorization' => "Bearer {$this->apiToken}",
                        'Content-Type' => 'application/json',
                        'Accept' => 'application/json',
                    ],
                    'json' => [
                        'target' => 'ExampleTarget',
                        'version' => '1.0.1',
                        'endpoint' => 'getUsersWithTimeout',
                        'data' => json_encode($data),
                        'mode' => $this->async ? 'async' : 'sync',
                        'callback_url' => $this->callbackUrl,
                    ],
                ]
            );

            return $response;
        } catch (\Exception $e) {
            throw $e;
        }
    }
}