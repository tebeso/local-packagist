<?php

namespace Terminal2\ApiClient\Http;

use Psr\Http\Message\ResponseInterface;

class ApiResponse
{
    private ResponseInterface $response;
    private ?array $decodedBody = null;

    public function __construct(ResponseInterface $response)
    {
        $this->response = $response;
    }

    public function getStatusCode(): int
    {
        return $this->response->getStatusCode();
    }

    public function getHeaders(): array
    {
        return $this->response->getHeaders();
    }

    public function getBody(): string
    {
        return (string) $this->response->getBody();
    }

    public function json(): ?array
    {
        if ($this->decodedBody === null) {
            $body = $this->getBody();
            $this->decodedBody = !empty($body) ? json_decode($body, true) : null;
        }

        return $this->decodedBody;
    }

    public function isSuccess(): bool
    {
        return $this->getStatusCode() >= 200 && $this->getStatusCode() < 300;
    }
}