<?php

namespace Terminal2\ApiClient\Http;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Terminal2\ApiClient\Exceptions\ApiException;

class HttpClient
{
    private Client $client;

    public function __construct(array $config = [])
    {
        $this->client = new Client($config);
    }

    /**
     * Send a request to the API
     *
     * Automatically adds Accept: application/json header to all requests
     */
    public function request(string $method, string $url, array $options = []): ApiResponse
    {
        // Ensure headers array exists
        if (!isset($options['headers'])) {
            $options['headers'] = [];
        }

        // Add Accept: application/json header if not already set
        if (!isset($options['headers']['Accept'])) {
            $options['headers']['Accept'] = 'application/json';
        }

        try {
            $response = $this->client->request($method, $url, $options);
            return new ApiResponse($response);
        } catch (GuzzleException $e) {
            throw new ApiException($e->getMessage(), $e->getCode(), $e);
        }
    }
}