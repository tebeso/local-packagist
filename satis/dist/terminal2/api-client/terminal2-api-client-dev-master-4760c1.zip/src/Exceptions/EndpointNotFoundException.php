<?php

namespace Terminal2\ApiClient\Exceptions;

class EndpointNotFoundException extends ApiException
{
    public function __construct(string $endpoint = "", int $code = 404, \Throwable $previous = null)
    {
        $message = !empty($endpoint) ? "Endpoint '{$endpoint}' not found" : "Endpoint not found";
        parent::__construct($message, $code, $previous);
    }
}