<?php

namespace Terminal2\ApiClient\Exceptions;

use Exception;

class ApiException extends Exception
{
    // Base exception for API-related errors
}