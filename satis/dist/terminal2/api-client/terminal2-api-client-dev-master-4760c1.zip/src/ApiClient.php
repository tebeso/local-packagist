<?php

namespace Terminal2\ApiClient;

use Terminal2\ApiClient\Http\HttpClient;
use Terminal2\ApiClient\Exceptions\ApiException;

class ApiClient
{
    private HttpClient $httpClient;
    private string $baseUrl;
    private ?string $apiToken = null;
    private ?string $clientId = null;
    private ?string $clientSecret = null;

    public function __construct(string $baseUrl)
    {
        $this->baseUrl = $baseUrl;
        $this->httpClient = new HttpClient();
    }

    public static function create(string $baseUrl): self
    {
        return new self($baseUrl);
    }

    public function withToken(string $token): self
    {
        $this->apiToken = $token;
        return $this;
    }

    /**
     * Set client credentials for OAuth authentication
     *
     * @param string $clientId The client ID
     * @param string $clientSecret The client secret
     * @return self
     */
    public function withClientCredentials(string $clientId, string $clientSecret): self
    {
        $this->clientId = $clientId;
        $this->clientSecret = $clientSecret;
        return $this;
    }

    /**
     * Authenticate using client credentials grant type
     *
     * @return self
     * @throws ApiException If authentication fails
     */
    public function authenticate(): self
    {
        if ($this->clientId === null || $this->clientSecret === null) {
            throw new ApiException('Client credentials not set. Use withClientCredentials() first.');
        }

        $response = $this->httpClient->request(
            'POST',
            "{$this->baseUrl}/oauth/token",
            [
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'grant_type' => 'client_credentials',
                    'client_id' => $this->clientId,
                    'client_secret' => $this->clientSecret,
                ],
            ]
        );

        $data = $response->json();

        if (!isset($data['access_token'])) {
            throw new ApiException('Failed to obtain access token');
        }

        $this->apiToken = $data['access_token'];
        return $this;
    }

    /**
     * Magic method to handle dynamic endpoint access
     *
     * Automatically authenticates using client credentials if they are set and no token is available
     */
    public function __call(string $name, array $arguments): mixed
    {
        // If client credentials are set but no token is available, authenticate automatically
        if ($this->apiToken === null && $this->clientId !== null && $this->clientSecret !== null) {
            $this->authenticate();
        }

        $endpointClass = 'Terminal2\ApiClient\\Endpoints\\' . ucfirst($name) . 'Endpoint';

        if (class_exists($endpointClass)) {
            return new $endpointClass($this->httpClient, $this->baseUrl, $this->apiToken);
        }

        throw new \BadMethodCallException("Endpoint '{$name}' does not exist");
    }
}